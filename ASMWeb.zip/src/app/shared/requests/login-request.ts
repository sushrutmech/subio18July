export interface LoginRequest {
    emailAddress: string;
    password: string;
}