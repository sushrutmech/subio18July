export interface SuccessGoalRequest {
    userSuccessID: number;
    userId: number;
    successGoalTypeID: number;
    goal: string;
    goalDesc: string;
}