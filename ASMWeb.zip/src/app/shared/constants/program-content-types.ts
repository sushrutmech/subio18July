export enum ProgramContentTypes {
  Web_Article = 1,
  Exercise = 2,
  Video = 3,
  Reading = 4,
  PDF_Document = 5,
}
