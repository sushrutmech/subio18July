export interface User {
  
  userID: number;
  firstName: string;
  lastName: string;
  preferredName: string,
  jobTitle: string,
  contactNumber: number,
  profilePic: string,
  emailAddress: string

}