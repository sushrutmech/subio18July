export interface GoalType {
  successGoalTypeID: number;
  sucessGoalTypeName: string;
  icon?: any;
  orderNo: number;

  //Not Mapped
  isSelected: boolean;
}
