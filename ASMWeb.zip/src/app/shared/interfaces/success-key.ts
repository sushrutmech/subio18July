export interface SuccessKey {
  categoryName: string;
  scorePC: number;
  rag: string;
  orderNo: number;
  previousScore: number;
  userAssessmentID: number;
}
