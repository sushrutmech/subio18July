import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p400',
  templateUrl: './p400.component.html',
  styleUrls: ['./p400.component.css']
})
export class P400Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
