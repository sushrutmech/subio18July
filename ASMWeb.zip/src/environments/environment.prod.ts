const baseURL = 'https://subioapi.azurewebsites.net/';

export const environment = {
  production: true,
  serverURL: baseURL,
  apiEndPoint: `${baseURL}api`
};
